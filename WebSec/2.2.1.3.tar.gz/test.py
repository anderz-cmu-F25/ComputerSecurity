import hashlib
import itertools
import string
import time

def find_any_in_md5(target, input_length):
    target = target.encode()
    
    # Define the character set (you can include more symbols if needed)
    charset = string.ascii_letters + string.digits  # 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    
    # Generate combinations of characters up to a certain length
    for input_tuple in itertools.product(charset, repeat=input_length):
        input_str = ''.join(input_tuple)  # Convert tuple to string

        # Compute MD5 hash of the input
        md5_hash = hashlib.md5(input_str.encode()).digest()  # Raw byte output

        # Check if the raw MD5 output contains any of the target byte sequences
        if target in md5_hash:
            print(f"Input '{input_str}' produces an MD5 hash containing <{target.decode()}>.")
            print(f"Raw MD5 hash: {md5_hash}")
            return  # Stop searching once any match is found

# Example usage:
start_time = time.time()
print("running...\n")
find_any_in_md5("'='", 4)
end_time = time.time()
print(f"\nfinsished in {end_time - start_time:.2f}s")
